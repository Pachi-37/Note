# These are custom snippets that suit my needs
