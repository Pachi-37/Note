## My NeoVim Config

### Documentation:

#### Check Out [This](https://kjhuanhao.github.io/2019/08/24/Theniceboy-s-nvim-configuration/) by [kjhuanhao](https://github.com/kjhuanhao)

#### Simplified Version Coming Up...
